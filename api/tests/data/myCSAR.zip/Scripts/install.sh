echo "install script started..."
apt-get install python
echo "...install script ended"